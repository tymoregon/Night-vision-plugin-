from endstone.plugin import Plugin
from endstone.command import Command, CommandSender
from endstone import ColorFormat


class NightVisionPlugin(Plugin):

    api_version = "0.6"

    name = "NightVisionPlugin"
    version = "1.1.0"
    description = "Выдаёт ночное зрение на 300 минут "
    authors = ["tymoregon"]

    commands = {
        "nv": {
            "description": "Включить ночное зрение на 300 минут",
            "usages": ["/nv"],
            "permissions": ["nightvision.command.nv"],
        }
    }

    permissions = {
        "nightvision.command.nv": {
            "description": "Разрешает использование команды /nv",
            "default": True,
        }
    }

    def on_enable(self) -> None:
        self.logger.info(ColorFormat.GREEN + "NightVisionPlugin успешно загружен!")

    def on_disable(self) -> None:
        self.logger.info(ColorFormat.RED + "NightVisionPlugin выгружен.")

    def on_command(
        self,
        sender: CommandSender,
        command: Command,
        args: list[str],
    ) -> bool:

        if command.name != "nv":
            return False

        from endstone import Player
        if not isinstance(sender, Player):
            sender.send_message(ColorFormat.RED + "Эта команда доступна только игрокам!")
            return True

        player: Player = sender
        duration: int = 300 * 60

        player.perform_command(f"effect @s night_vision {duration} 0 true")

        player.send_message(
            ColorFormat.AQUA
            + "Ночное зрение активировано на "
            + ColorFormat.YELLOW + "300 минут"
            + ColorFormat.AQUA + "!"
        )

        self.logger.info(
            f"[NightVision] {player.name} использовал /nv "
            f"(ночное зрение на {duration // 60} мин)"
        )

        return True
